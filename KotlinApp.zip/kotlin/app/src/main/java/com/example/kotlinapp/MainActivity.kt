package com.example.kotlinapp

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var btn: Button = findViewById(R.id.b1);
        btn.setOnClickListener {
            val intent = Intent(this, quiz::class.java)
            startActivity(intent);
            finish();
        }
        var btn2: Button = findViewById(R.id.quit);
        btn2.setOnClickListener {
            //finish();
            System.exit(1);
        }

    }
}
