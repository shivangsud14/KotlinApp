package com.example.kotlinapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Res : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_res)
        //val i = intent
        var num:Int = intent.getIntExtra("res",0);
        var messg:String = intent.getStringExtra("msg");
        var tx1:TextView=findViewById(R.id.tv1);
        var tx2:TextView=findViewById(R.id.tv2);
        tx1.text = quiz.mssg;
        tx2.text = quiz.res.toString();

        var btn1: Button = findViewById(R.id.tab);
        btn1.setOnClickListener {
            val i1 = Intent(this, MainActivity::class.java)
            startActivity(i1);
        }
        var btn2: Button = findViewById(R.id.qb);
        btn2.setOnClickListener {
            //finish();
            System.exit(1);
        }


    }
}
