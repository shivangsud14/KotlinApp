package com.example.kotlinapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.Toast

class quiz : AppCompatActivity() {
    companion object{
        var mssg="";
        var res:Int=0;
    }
    fun incrementer()
    {
        res+=2;
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)
        mssg="";
        res=0;
        var rba1:RadioButton = findViewById(R.id.q12);
        var rba2:RadioButton = findViewById(R.id.q21);
        var rba3:RadioButton = findViewById(R.id.q31);
        var rba4:RadioButton = findViewById(R.id.q42);
        var rba5:RadioButton = findViewById(R.id.q52);
        var btnres: Button = findViewById(R.id.sub);
        btnres.setOnClickListener {

            if (rba1.isChecked)
            {
                incrementer()
            }
            if (rba2.isChecked)
            {
                incrementer();
            }
            if (rba3.isChecked)
            {
                incrementer()
            }
            if (rba4.isChecked)
            {
                incrementer()
            }
            if (rba5.isChecked)
            {
                incrementer()
            }
            if (res>=8)
            {
                 mssg="Well Done!";
            }
            if (res==6)
            {
                mssg="Not Bad...";
            }
            if (res<=4)
            {
                 mssg="Better Luck next time :(";
            }

            val i = Intent(this, Res::class.java)
            i.putExtra("result",res);
            i.putExtra("msg",mssg);
            startActivity(i);
            finish();
        }

    }
}
